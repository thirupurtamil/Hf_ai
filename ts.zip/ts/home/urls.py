from django.urls import path,include 
from home import views


urlpatterns = [
    path('acb/', views.home1, name='acb'),
]
   
    
    
   
 
   
